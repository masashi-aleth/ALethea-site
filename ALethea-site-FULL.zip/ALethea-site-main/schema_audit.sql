-- ALethea: append-only audit log (Stage 12). Run manually in Supabase SQL Editor AFTER schema.sql and schema_support.sql.
-- Safe to re-run. NOT executed against a real database by the author: run it and report any error.
-- Only admins can read it. Nobody (not even admins) can edit or delete rows through the API.
-- Logged: ticket created / replied / status or priority changed, and member role changes. No message text, no passwords, no tokens.

create table if not exists public.audit_log (
  id bigint generated always as identity primary key,
  at timestamptz not null default now(),
  actor uuid,
  action text not null check (char_length(action) between 1 and 60),
  target text check (char_length(target) <= 120),
  severity text not null default 'info' check (severity in ('info','warn','critical')),
  meta jsonb not null default '{}'::jsonb check (octet_length(meta::text) < 2000)
);
create index if not exists audit_log_at_idx on public.audit_log (at desc);
create index if not exists audit_log_action_idx on public.audit_log (action, at desc);
alter table public.audit_log enable row level security;
revoke all on table public.audit_log from anon, authenticated;
grant select on table public.audit_log to authenticated;
drop policy if exists "admins read audit" on public.audit_log;
create policy "admins read audit" on public.audit_log for select to authenticated using ((select public.is_admin()));

create or replace function public.tg_audit_immutable() returns trigger language plpgsql as $$
begin raise exception 'audit_log is append-only'; end $$;
drop trigger if exists audit_log_no_change on public.audit_log;
create trigger audit_log_no_change before update or delete on public.audit_log
  for each row execute function public.tg_audit_immutable();

create or replace function public.audit_write(a text, t text, s text, m jsonb) returns void
language sql security definer set search_path = '' as $$
  insert into public.audit_log (actor, action, target, severity, meta) values (auth.uid(), a, t, s, coalesce(m, '{}'::jsonb));
$$;
revoke all on function public.audit_write(text, text, text, jsonb) from public, anon, authenticated;

create or replace function public.tg_audit_ticket() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    perform public.audit_write('ticket.create', new.ref, 'info', jsonb_build_object('category', new.category, 'priority', new.priority));
  elsif pg_trigger_depth() = 1 and (new.status is distinct from old.status or new.priority is distinct from old.priority) then
    perform public.audit_write('ticket.update', new.ref, 'info', jsonb_build_object('status_from', old.status, 'status_to', new.status, 'priority_from', old.priority, 'priority_to', new.priority));
  end if;
  return null;
end $$;
drop trigger if exists support_tickets_audit_ins on public.support_tickets;
drop trigger if exists support_tickets_audit_upd on public.support_tickets;
create trigger support_tickets_audit_ins after insert on public.support_tickets for each row execute function public.tg_audit_ticket();
create trigger support_tickets_audit_upd after update on public.support_tickets for each row execute function public.tg_audit_ticket();

create or replace function public.tg_audit_message() returns trigger language plpgsql security definer set search_path = '' as $$
declare r text;
begin
  select ref into r from public.support_tickets where id = new.ticket_id;
  perform public.audit_write('ticket.reply', r, 'info', jsonb_build_object('staff', new.is_staff));
  return null;
end $$;
drop trigger if exists ticket_messages_audit on public.ticket_messages;
create trigger ticket_messages_audit after insert on public.ticket_messages for each row execute function public.tg_audit_message();

create or replace function public.tg_audit_role() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  perform public.audit_write('role.change', new.id::text, 'critical', jsonb_build_object('from', old.role, 'to', new.role));
  return null;
end $$;
drop trigger if exists profiles_audit_role on public.profiles;
create trigger profiles_audit_role after update of role on public.profiles
  for each row when (old.role is distinct from new.role) execute function public.tg_audit_role();
