-- ALethea: per-account settings (Stage 1 of the production plan). Run manually in Supabase SQL Editor after schema.sql.
-- Safe to re-run. Creates one new table; changes nothing that exists.
-- Each signed-in user can read and write ONLY their own row (enforced by RLS on the server).

create table if not exists public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  theme jsonb not null default '{}'::jsonb check (octet_length(theme::text) < 4000),
  updated_at timestamptz not null default now()
);
alter table public.user_settings enable row level security;

revoke all on table public.user_settings from anon, authenticated;
grant select, insert, update, delete on table public.user_settings to authenticated;

drop policy if exists "own settings select" on public.user_settings;
drop policy if exists "own settings insert" on public.user_settings;
drop policy if exists "own settings update" on public.user_settings;
drop policy if exists "own settings delete" on public.user_settings;

create policy "own settings select" on public.user_settings
  for select to authenticated using (user_id = (select auth.uid()));
create policy "own settings insert" on public.user_settings
  for insert to authenticated with check (user_id = (select auth.uid()));
create policy "own settings update" on public.user_settings
  for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "own settings delete" on public.user_settings
  for delete to authenticated using (user_id = (select auth.uid()));
