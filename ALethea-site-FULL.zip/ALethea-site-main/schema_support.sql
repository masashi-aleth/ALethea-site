-- ALethea: support tickets + notifications (Stage 11). Run manually in Supabase SQL Editor AFTER schema.sql.
-- Safe to re-run. Creates new tables only. NOT executed against a real database by the author: run it and report any error.
-- Rules enforced by the server (RLS + triggers), never by the browser:
--   * a user sees and replies to only their own tickets; admins (public.is_admin()) see and answer all
--   * is_staff and author_id are set by a trigger, so a user cannot pose as staff
--   * only admins change status/priority; clients can never create notifications

create table if not exists public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  ref text not null unique default ('AL-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8))),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  subject text not null check (char_length(subject) between 3 and 120),
  category text not null default 'general' check (category in ('general','account','store','bug','other')),
  priority text not null default 'normal' check (priority in ('low','normal','high')),
  status text not null default 'open' check (status in ('open','in_progress','waiting_user','resolved')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists support_tickets_user_idx on public.support_tickets (user_id, updated_at desc);
create index if not exists support_tickets_status_idx on public.support_tickets (status, updated_at desc);

create table if not exists public.ticket_messages (
  id bigint generated always as identity primary key,
  ticket_id uuid not null references public.support_tickets(id) on delete cascade,
  author_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  is_staff boolean not null default false,
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now()
);
create index if not exists ticket_messages_ticket_idx on public.ticket_messages (ticket_id, created_at);

create table if not exists public.notifications (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  ticket_id uuid references public.support_tickets(id) on delete cascade,
  kind text not null check (kind in ('reply','user_reply','status')),
  ref text,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_idx on public.notifications (user_id, read, created_at desc);

alter table public.support_tickets enable row level security;
alter table public.ticket_messages enable row level security;
alter table public.notifications enable row level security;

revoke all on table public.support_tickets, public.ticket_messages, public.notifications from anon, authenticated;
grant select, insert on public.support_tickets to authenticated;
grant update (status, priority) on public.support_tickets to authenticated;   -- RLS below limits this to admins
grant select, insert on public.ticket_messages to authenticated;
grant select on public.notifications to authenticated;
grant update (read) on public.notifications to authenticated;

drop policy if exists "tickets select" on public.support_tickets;
drop policy if exists "tickets insert" on public.support_tickets;
drop policy if exists "tickets admin update" on public.support_tickets;
create policy "tickets select" on public.support_tickets for select to authenticated
  using (user_id = (select auth.uid()) or (select public.is_admin()));
create policy "tickets insert" on public.support_tickets for insert to authenticated
  with check (user_id = (select auth.uid()) and status = 'open');
create policy "tickets admin update" on public.support_tickets for update to authenticated
  using ((select public.is_admin())) with check ((select public.is_admin()));

drop policy if exists "messages select" on public.ticket_messages;
drop policy if exists "messages insert" on public.ticket_messages;
create policy "messages select" on public.ticket_messages for select to authenticated
  using (exists (select 1 from public.support_tickets t where t.id = ticket_id and (t.user_id = (select auth.uid()) or (select public.is_admin()))));
create policy "messages insert" on public.ticket_messages for insert to authenticated
  with check (exists (select 1 from public.support_tickets t where t.id = ticket_id and (t.user_id = (select auth.uid()) or (select public.is_admin()))));

drop policy if exists "notifs select own" on public.notifications;
drop policy if exists "notifs update own" on public.notifications;
create policy "notifs select own" on public.notifications for select to authenticated using (user_id = (select auth.uid()));
create policy "notifs update own" on public.notifications for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- Before insert: the server decides who wrote the message and whether they are staff.
create or replace function public.tg_message_before() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  new.author_id := auth.uid();
  new.is_staff := coalesce(public.is_admin(), false);
  return new;
end $$;
drop trigger if exists ticket_messages_before on public.ticket_messages;
create trigger ticket_messages_before before insert on public.ticket_messages
  for each row execute function public.tg_message_before();

-- After insert: update the ticket and notify the other side.
create or replace function public.tg_message_after() returns trigger
language plpgsql security definer set search_path = '' as $$
declare t public.support_tickets;
begin
  select * into t from public.support_tickets where id = new.ticket_id;
  if new.is_staff then
    update public.support_tickets set updated_at = now(),
      status = case when status = 'open' then 'in_progress' else status end where id = t.id;
    insert into public.notifications (user_id, ticket_id, kind, ref) values (t.user_id, t.id, 'reply', t.ref);
  else
    update public.support_tickets set updated_at = now(),
      status = case when status in ('waiting_user','resolved') then 'open' else status end where id = t.id;
    insert into public.notifications (user_id, ticket_id, kind, ref)
      select p.id, t.id, 'user_reply', t.ref from public.profiles p where p.role = 'admin';
  end if;
  return new;
end $$;
drop trigger if exists ticket_messages_after on public.ticket_messages;
create trigger ticket_messages_after after insert on public.ticket_messages
  for each row execute function public.tg_message_after();

-- After a direct status change by an admin (depth 1 = not caused by the message trigger): notify the owner.
create or replace function public.tg_ticket_status() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if new.status is distinct from old.status and pg_trigger_depth() = 1 then
    new.updated_at := now();
  end if;
  return new;
end $$;
create or replace function public.tg_ticket_status_after() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if new.status is distinct from old.status and pg_trigger_depth() = 1 then
    insert into public.notifications (user_id, ticket_id, kind, ref) values (new.user_id, new.id, 'status', new.ref);
  end if;
  return null;
end $$;
drop trigger if exists support_tickets_status_before on public.support_tickets;
drop trigger if exists support_tickets_status_after on public.support_tickets;
create trigger support_tickets_status_before before update on public.support_tickets
  for each row execute function public.tg_ticket_status();
create trigger support_tickets_status_after after update of status on public.support_tickets
  for each row execute function public.tg_ticket_status_after();
